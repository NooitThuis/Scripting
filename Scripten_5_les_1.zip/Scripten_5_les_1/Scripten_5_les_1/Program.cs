﻿using System;

namespace Scripten_5_les_1
{
    class Program
    {
        #region part1
        // creating the directions.
        enum directions { north, south, east, west }
        #endregion

        static void Main(string[] args)
        {
            enumber();

            void enumber()
            {
                #region part2
                int ChosenDirection = 0;
                // Ask the user to input one of the available directions.
                Console.WriteLine("Choose a direction");
                Console.WriteLine("[0]North | [1]South | [2]East | [3]West");
                ChosenDirection = int.Parse(Console.ReadLine());

                // Use an if statement to check the input and display a different message for every possible option.
                if (ChosenDirection < 0 | ChosenDirection > 3)
                {
                    enumber();
                }
                else
                {
                    // Declared variable named 'playerDirection' of the enum 'Directions'.
                    var playerDirection = (directions)ChosenDirection;
                    Console.WriteLine((directions)ChosenDirection);

                    enumber2();
                }
                #endregion

                #region part3
                void enumber2()
                {
                    // Creating variables.
                    string DirectionChosen;

                    // Ask the user to input one of the available directions.
                    Console.WriteLine("Choose a direction");
                    Console.WriteLine("North | South | East | West");

                    DirectionChosen = Console.ReadLine();

                    // If statement that prints out result for the chosen input.
                    if (DirectionChosen == directions.north.ToString())
                    {
                        Console.WriteLine("You chose, North.");
                    } else if (DirectionChosen == directions.south.ToString())
                    {
                        Console.WriteLine("You chose, South.");
                    }
                    else if (DirectionChosen == directions.east.ToString())
                    {
                        Console.WriteLine("You chose, East.");
                    }
                    else if (DirectionChosen == directions.west.ToString())
                    {
                        Console.WriteLine("You chose, West.");
                    }
                }
                #endregion
            }
        }
    }
}
